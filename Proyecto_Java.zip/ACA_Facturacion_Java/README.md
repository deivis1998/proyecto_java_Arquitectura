# Sistema de facturación comercial en Java

Proyecto base del ACA sobre arquitectura en capas. Incluye una aplicación de consola, las entidades del dominio, los servicios de aplicación, repositorios en memoria y ocho pruebas de negocio.

## Requisitos

- JDK 17 o posterior.
- Maven 3.9 o posterior.

## Ejecutar el programa

Desde la carpeta del proyecto:

```bash
mvn clean compile exec:java
```

## Ejecutar las pruebas

```bash
mvn test
```

## Capas

- `presentacion`: menú de consola y comunicación con el usuario.
- `aplicacion`: casos de uso, servicios e interfaces de repositorio.
- `dominio`: entidades, cálculos y reglas de negocio.
- `infraestructura`: almacenamiento en memoria reemplazable por una base de datos.

Lee `INSTRUCCIONES_DE_TRABAJO.md` antes de modificar el proyecto.
