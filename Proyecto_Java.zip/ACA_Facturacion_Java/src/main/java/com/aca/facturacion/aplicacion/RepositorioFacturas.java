package com.aca.facturacion.aplicacion;

import com.aca.facturacion.dominio.Factura;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RepositorioFacturas {
    Optional<Factura> buscarPorId(UUID id);
    Optional<Factura> buscarPorNumero(String numero);
    List<Factura> listar();
    List<Factura> buscarPorCliente(UUID clienteId);
    List<Factura> buscarPorRango(LocalDateTime desde, LocalDateTime hasta);
    void guardar(Factura factura);
    void actualizar(Factura factura);
    int siguienteConsecutivo();
}
