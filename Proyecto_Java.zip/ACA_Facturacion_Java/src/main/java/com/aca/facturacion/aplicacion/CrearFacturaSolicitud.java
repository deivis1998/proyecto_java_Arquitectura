package com.aca.facturacion.aplicacion;

import java.util.List;
import java.util.UUID;

public record CrearFacturaSolicitud(UUID clienteId, List<ItemFacturaSolicitud> items) {
    public CrearFacturaSolicitud {
        items = List.copyOf(items);
    }
}
