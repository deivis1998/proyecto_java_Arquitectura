package com.aca.facturacion.infraestructura;

import com.aca.facturacion.aplicacion.RepositorioProductos;
import com.aca.facturacion.dominio.Producto;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class RepositorioProductosMemoria implements RepositorioProductos {
    private final Map<UUID, Producto> datos = new LinkedHashMap<>();

    @Override
    public Optional<Producto> buscarPorId(UUID id) {
        return Optional.ofNullable(datos.get(id));
    }

    @Override
    public Optional<Producto> buscarPorCodigo(String codigo) {
        return datos.values().stream()
                .filter(producto -> producto.getCodigo().equalsIgnoreCase(codigo.trim()))
                .findFirst();
    }

    @Override
    public List<Producto> listar() {
        List<Producto> resultado = new ArrayList<>(datos.values());
        resultado.sort(Comparator.comparing(Producto::getCodigo));
        return List.copyOf(resultado);
    }

    @Override
    public void guardar(Producto producto) {
        datos.put(producto.getId(), producto);
    }

    @Override
    public void actualizar(Producto producto) {
        datos.put(producto.getId(), producto);
    }
}
