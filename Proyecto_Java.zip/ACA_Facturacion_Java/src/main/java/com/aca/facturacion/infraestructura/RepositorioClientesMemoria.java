package com.aca.facturacion.infraestructura;

import com.aca.facturacion.aplicacion.RepositorioClientes;
import com.aca.facturacion.dominio.Cliente;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class RepositorioClientesMemoria implements RepositorioClientes {
    private final Map<UUID, Cliente> datos = new LinkedHashMap<>();

    @Override
    public Optional<Cliente> buscarPorId(UUID id) {
        return Optional.ofNullable(datos.get(id));
    }

    @Override
    public Optional<Cliente> buscarPorIdentificacion(String identificacion) {
        return datos.values().stream()
                .filter(cliente -> cliente.getIdentificacion().equalsIgnoreCase(identificacion.trim()))
                .findFirst();
    }

    @Override
    public List<Cliente> listar() {
        List<Cliente> resultado = new ArrayList<>(datos.values());
        resultado.sort(Comparator.comparing(Cliente::getNombreORazonSocial));
        return List.copyOf(resultado);
    }

    @Override
    public void guardar(Cliente cliente) {
        datos.put(cliente.getId(), cliente);
    }

    @Override
    public void actualizar(Cliente cliente) {
        datos.put(cliente.getId(), cliente);
    }
}
