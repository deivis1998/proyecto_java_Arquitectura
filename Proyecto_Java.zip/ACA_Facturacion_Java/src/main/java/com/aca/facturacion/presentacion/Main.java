package com.aca.facturacion.presentacion;

import com.aca.facturacion.aplicacion.CrearFacturaSolicitud;
import com.aca.facturacion.aplicacion.ItemFacturaSolicitud;
import com.aca.facturacion.aplicacion.ServicioClientes;
import com.aca.facturacion.aplicacion.ServicioFacturacion;
import com.aca.facturacion.aplicacion.ServicioProductos;
import com.aca.facturacion.dominio.Cliente;
import com.aca.facturacion.dominio.EstadoCliente;
import com.aca.facturacion.dominio.ExcepcionNegocio;
import com.aca.facturacion.dominio.Factura;
import com.aca.facturacion.dominio.LineaFactura;
import com.aca.facturacion.dominio.Producto;
import com.aca.facturacion.infraestructura.RepositorioClientesMemoria;
import com.aca.facturacion.infraestructura.RepositorioFacturasMemoria;
import com.aca.facturacion.infraestructura.RepositorioProductosMemoria;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    private static final Scanner TECLADO = new Scanner(System.in);
    private static final NumberFormat MONEDA = NumberFormat.getCurrencyInstance(new Locale("es", "CO"));
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final ServicioClientes servicioClientes;
    private final ServicioProductos servicioProductos;
    private final ServicioFacturacion servicioFacturacion;

    public Main() {
        RepositorioClientesMemoria clientes = new RepositorioClientesMemoria();
        RepositorioProductosMemoria productos = new RepositorioProductosMemoria();
        RepositorioFacturasMemoria facturas = new RepositorioFacturasMemoria();
        servicioClientes = new ServicioClientes(clientes);
        servicioProductos = new ServicioProductos(productos);
        servicioFacturacion = new ServicioFacturacion(clientes, productos, facturas);
        cargarDatosIniciales();
    }

    public static void main(String[] args) {
        new Main().ejecutar();
    }

    private void ejecutar() {
        while (true) {
            mostrarMenu();
            String opcion = TECLADO.nextLine().trim();
            try {
                switch (opcion) {
                    case "1" -> gestionarClientes();
                    case "2" -> gestionarProductos();
                    case "3" -> crearFactura();
                    case "4" -> listarFacturas(servicioFacturacion.listar());
                    case "5" -> mostrarDetalle(seleccionarFactura());
                    case "6" -> anularFactura();
                    case "7" -> consultarHistorial();
                    case "8" -> consultarPorFechas();
                    case "0" -> {
                        System.out.println("Programa finalizado.");
                        return;
                    }
                    default -> System.out.println("Opción no válida.");
                }
            } catch (ExcepcionNegocio | IllegalArgumentException ex) {
                System.out.println("ERROR: " + ex.getMessage());
            }
            pausar();
        }
    }

    private void mostrarMenu() {
        System.out.println("\n============================================================");
        System.out.println("     SISTEMA DE FACTURACIÓN - ARQUITECTURA EN CAPAS");
        System.out.println("============================================================");
        System.out.println("1. Gestionar clientes");
        System.out.println("2. Gestionar productos");
        System.out.println("3. Crear factura");
        System.out.println("4. Consultar todas las facturas");
        System.out.println("5. Consultar detalle de factura");
        System.out.println("6. Anular factura");
        System.out.println("7. Historial por cliente");
        System.out.println("8. Facturas por rango de fechas");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private void gestionarClientes() {
        System.out.println("\n1. Listar clientes");
        System.out.println("2. Registrar cliente");
        System.out.println("3. Cambiar estado");
        System.out.print("Opción: ");
        switch (TECLADO.nextLine().trim()) {
            case "1" -> listarClientes();
            case "2" -> registrarCliente();
            case "3" -> cambiarEstadoCliente();
            default -> System.out.println("Opción no válida.");
        }
    }

    private void registrarCliente() {
        System.out.print("Nombre o razón social: ");
        String nombre = leerTextoObligatorio();
        System.out.print("Identificación/NIT: ");
        String identificacion = leerTextoObligatorio();
        System.out.print("Correo: ");
        String correo = leerTextoObligatorio();
        System.out.print("Dirección: ");
        String direccion = TECLADO.nextLine();
        System.out.print("Teléfono: ");
        String telefono = TECLADO.nextLine();
        Cliente cliente = servicioClientes.registrar(
                nombre, identificacion, correo, direccion, telefono, EstadoCliente.ACTIVO);
        System.out.println("Cliente registrado: " + cliente.getNombreORazonSocial());
    }

    private void cambiarEstadoCliente() {
        Cliente cliente = seleccionarCliente();
        System.out.println("1. ACTIVO | 2. INACTIVO | 3. BLOQUEADO POR MORA");
        int opcion = leerEntero("Nuevo estado: ", 1, 3);
        EstadoCliente estado = EstadoCliente.values()[opcion - 1];
        servicioClientes.cambiarEstado(cliente.getId(), estado);
        System.out.println("Estado actualizado.");
    }

    private void gestionarProductos() {
        System.out.println("\n1. Listar productos");
        System.out.println("2. Registrar producto");
        System.out.print("Opción: ");
        switch (TECLADO.nextLine().trim()) {
            case "1" -> listarProductos();
            case "2" -> registrarProducto();
            default -> System.out.println("Opción no válida.");
        }
    }

    private void registrarProducto() {
        System.out.print("Código: ");
        String codigo = leerTextoObligatorio();
        System.out.print("Descripción: ");
        String descripcion = leerTextoObligatorio();
        BigDecimal precio = leerDecimal("Precio unitario: ", BigDecimal.ZERO, null);
        int stock = leerEntero("Stock inicial: ", 0, Integer.MAX_VALUE);
        BigDecimal iva = leerDecimal("Porcentaje de IVA: ", BigDecimal.ZERO, new BigDecimal("100"));
        Producto producto = servicioProductos.registrar(codigo, descripcion, precio, stock, iva);
        System.out.println("Producto registrado: " + producto.getDescripcion());
    }

    private void crearFactura() {
        Cliente cliente = seleccionarCliente();
        List<ItemFacturaSolicitud> items = new ArrayList<>();
        do {
            Producto producto = seleccionarProducto();
            int cantidad = leerEntero("Cantidad: ", 1, Integer.MAX_VALUE);
            items.add(new ItemFacturaSolicitud(producto.getId(), cantidad));
            System.out.print("¿Agregar otro producto? (s/n): ");
        } while (TECLADO.nextLine().trim().equalsIgnoreCase("s"));

        Factura factura = servicioFacturacion.crearFactura(
                new CrearFacturaSolicitud(cliente.getId(), items));
        System.out.println("Factura " + factura.getNumero() + " generada correctamente.");
        mostrarDetalle(factura);
    }

    private void anularFactura() {
        Factura factura = seleccionarFactura();
        servicioFacturacion.anularFactura(factura.getId());
        System.out.println("Factura " + factura.getNumero() + " anulada.");
    }

    private void consultarHistorial() {
        Cliente cliente = seleccionarCliente();
        listarFacturas(servicioFacturacion.buscarPorCliente(cliente.getId()));
    }

    private void consultarPorFechas() {
        LocalDate desde = leerFecha("Fecha inicial (dd/MM/yyyy): ");
        LocalDate hasta = leerFecha("Fecha final (dd/MM/yyyy): ");
        listarFacturas(servicioFacturacion.buscarPorRango(desde, hasta));
    }

    private Cliente seleccionarCliente() {
        List<Cliente> clientes = servicioClientes.listar();
        if (clientes.isEmpty()) {
            throw new ExcepcionNegocio("No hay clientes registrados.");
        }
        for (int i = 0; i < clientes.size(); i++) {
            Cliente cliente = clientes.get(i);
            System.out.printf("%d. %s | %s | %s%n", i + 1,
                    cliente.getNombreORazonSocial(), cliente.getIdentificacion(), cliente.getEstado());
        }
        return clientes.get(leerEntero("Seleccione el cliente: ", 1, clientes.size()) - 1);
    }

    private Producto seleccionarProducto() {
        List<Producto> productos = servicioProductos.listar();
        if (productos.isEmpty()) {
            throw new ExcepcionNegocio("No hay productos registrados.");
        }
        for (int i = 0; i < productos.size(); i++) {
            Producto producto = productos.get(i);
            System.out.printf("%d. %s | %s | %s | Stock: %d | IVA: %s%%%n", i + 1,
                    producto.getCodigo(), producto.getDescripcion(), dinero(producto.getPrecioUnitario()),
                    producto.getStockDisponible(), producto.getPorcentajeIva());
        }
        return productos.get(leerEntero("Seleccione el producto: ", 1, productos.size()) - 1);
    }

    private Factura seleccionarFactura() {
        List<Factura> facturas = servicioFacturacion.listar();
        if (facturas.isEmpty()) {
            throw new ExcepcionNegocio("No hay facturas registradas.");
        }
        for (int i = 0; i < facturas.size(); i++) {
            Factura factura = facturas.get(i);
            System.out.printf("%d. %s | %s | %s | %s%n", i + 1,
                    factura.getNumero(), factura.getNombreCliente(), dinero(factura.calcularTotal()), factura.getEstado());
        }
        return facturas.get(leerEntero("Seleccione la factura: ", 1, facturas.size()) - 1);
    }

    private void listarClientes() {
        System.out.println("\nCLIENTES");
        servicioClientes.listar().forEach(cliente -> System.out.printf("- %s | %s | %s | %s%n",
                cliente.getNombreORazonSocial(), cliente.getIdentificacion(), cliente.getCorreo(), cliente.getEstado()));
    }

    private void listarProductos() {
        System.out.println("\nPRODUCTOS");
        servicioProductos.listar().forEach(producto -> System.out.printf("- %s | %s | %s | Stock: %d | IVA: %s%%%n",
                producto.getCodigo(), producto.getDescripcion(), dinero(producto.getPrecioUnitario()),
                producto.getStockDisponible(), producto.getPorcentajeIva()));
    }

    private void listarFacturas(List<Factura> facturas) {
        System.out.println("\nFACTURAS");
        if (facturas.isEmpty()) {
            System.out.println("No se encontraron facturas.");
            return;
        }
        facturas.forEach(factura -> System.out.printf("- %s | %s | %s | %s%n",
                factura.getNumero(), factura.getNombreCliente(), dinero(factura.calcularTotal()), factura.getEstado()));
    }

    private void mostrarDetalle(Factura factura) {
        System.out.println("\n============================================================");
        System.out.println("FACTURA: " + factura.getNumero() + " | ESTADO: " + factura.getEstado());
        System.out.println("CLIENTE: " + factura.getNombreCliente());
        for (LineaFactura linea : factura.getLineas()) {
            System.out.printf("%s - %s | %d x %s | IVA %s | Total %s%n",
                    linea.getCodigoProducto(), linea.getDescripcionProducto(), linea.getCantidad(),
                    dinero(linea.getPrecioUnitario()), dinero(linea.calcularIva()), dinero(linea.calcularTotal()));
        }
        System.out.println("Subtotal: " + dinero(factura.calcularSubtotal()));
        System.out.println("IVA:      " + dinero(factura.calcularIva()));
        System.out.println("TOTAL:    " + dinero(factura.calcularTotal()));
        System.out.println("============================================================");
    }

    private int leerEntero(String mensaje, int minimo, int maximo) {
        while (true) {
            System.out.print(mensaje);
            try {
                int valor = Integer.parseInt(TECLADO.nextLine().trim());
                if (valor >= minimo && valor <= maximo) {
                    return valor;
                }
            } catch (NumberFormatException ignored) {
            }
            System.out.println("Ingrese un número válido.");
        }
    }

    private BigDecimal leerDecimal(String mensaje, BigDecimal minimo, BigDecimal maximo) {
        while (true) {
            System.out.print(mensaje);
            try {
                BigDecimal valor = new BigDecimal(TECLADO.nextLine().trim().replace(',', '.'));
                if (valor.compareTo(minimo) >= 0 && (maximo == null || valor.compareTo(maximo) <= 0)) {
                    return valor;
                }
            } catch (NumberFormatException ignored) {
            }
            System.out.println("Ingrese un valor numérico válido.");
        }
    }

    private LocalDate leerFecha(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return LocalDate.parse(TECLADO.nextLine().trim(), FECHA);
            } catch (DateTimeParseException ignored) {
                System.out.println("Use el formato dd/MM/yyyy.");
            }
        }
    }

    private String leerTextoObligatorio() {
        String valor = TECLADO.nextLine().trim();
        if (valor.isBlank()) {
            throw new IllegalArgumentException("El valor es obligatorio.");
        }
        return valor;
    }

    private static String dinero(BigDecimal valor) {
        return MONEDA.format(valor);
    }

    private void pausar() {
        System.out.print("\nPresione Enter para continuar...");
        TECLADO.nextLine();
    }

    private void cargarDatosIniciales() {
        servicioClientes.registrar("Comercializadora Andina S.A.S.", "900123456-7",
                "compras@andina.test", "Bogotá", "6015550101", EstadoCliente.ACTIVO);
        servicioClientes.registrar("Tienda El Roble", "901987654-3",
                "contacto@elroble.test", "Medellín", "6045550102", EstadoCliente.INACTIVO);
        servicioClientes.registrar("Distribuciones del Caribe", "800765432-1",
                "pagos@caribe.test", "Barranquilla", "6055550103", EstadoCliente.BLOQUEADO_POR_MORA);

        servicioProductos.registrar("P001", "Teclado mecánico", new BigDecimal("185000"), 12, new BigDecimal("19"));
        servicioProductos.registrar("P002", "Mouse inalámbrico", new BigDecimal("82500"), 20, new BigDecimal("19"));
        servicioProductos.registrar("S001", "Servicio de instalación", new BigDecimal("120000"), 50, BigDecimal.ZERO);
    }
}
