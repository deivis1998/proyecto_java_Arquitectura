package com.aca.facturacion.dominio;

import java.util.Objects;
import java.util.UUID;

public class Cliente {
    private final UUID id;
    private String nombreORazonSocial;
    private String identificacion;
    private String correo;
    private String direccion;
    private String telefono;
    private EstadoCliente estado;

    public Cliente(
            UUID id,
            String nombreORazonSocial,
            String identificacion,
            String correo,
            String direccion,
            String telefono,
            EstadoCliente estado) {
        this.id = Objects.requireNonNull(id, "El identificador es obligatorio");
        this.nombreORazonSocial = textoObligatorio(nombreORazonSocial, "El nombre es obligatorio");
        this.identificacion = textoObligatorio(identificacion, "La identificación/NIT es obligatoria");
        this.correo = validarCorreo(correo);
        this.direccion = direccion == null ? "" : direccion.trim();
        this.telefono = telefono == null ? "" : telefono.trim();
        this.estado = Objects.requireNonNull(estado, "El estado es obligatorio");
    }

    public void validarPuedeFacturarse() {
        if (estado == EstadoCliente.INACTIVO) {
            throw new ExcepcionNegocio("No se puede generar una factura para un cliente inactivo.");
        }
        if (estado == EstadoCliente.BLOQUEADO_POR_MORA) {
            throw new ExcepcionNegocio("No se puede generar una factura para un cliente bloqueado por mora.");
        }
    }

    public void cambiarEstado(EstadoCliente nuevoEstado) {
        this.estado = Objects.requireNonNull(nuevoEstado, "El estado es obligatorio");
    }

    private static String validarCorreo(String correo) {
        String valor = textoObligatorio(correo, "El correo es obligatorio");
        if (!valor.contains("@")) {
            throw new IllegalArgumentException("El correo no es válido");
        }
        return valor;
    }

    private static String textoObligatorio(String valor, String mensaje) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(mensaje);
        }
        return valor.trim();
    }

    public UUID getId() { return id; }
    public String getNombreORazonSocial() { return nombreORazonSocial; }
    public String getIdentificacion() { return identificacion; }
    public String getCorreo() { return correo; }
    public String getDireccion() { return direccion; }
    public String getTelefono() { return telefono; }
    public EstadoCliente getEstado() { return estado; }
}
