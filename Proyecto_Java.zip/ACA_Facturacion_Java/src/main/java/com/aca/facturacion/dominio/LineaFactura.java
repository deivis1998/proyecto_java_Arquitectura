package com.aca.facturacion.dominio;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

public class LineaFactura {
    private final UUID productoId;
    private final String codigoProducto;
    private final String descripcionProducto;
    private final BigDecimal precioUnitario;
    private final int cantidad;
    private final BigDecimal porcentajeIva;

    public LineaFactura(Producto producto, int cantidad) {
        producto.validarStock(cantidad);
        this.productoId = producto.getId();
        this.codigoProducto = producto.getCodigo();
        this.descripcionProducto = producto.getDescripcion();
        this.precioUnitario = producto.getPrecioUnitario();
        this.cantidad = cantidad;
        this.porcentajeIva = producto.getPorcentajeIva();
    }

    public BigDecimal calcularSubtotal() {
        return precioUnitario.multiply(BigDecimal.valueOf(cantidad));
    }

    public BigDecimal calcularIva() {
        return calcularSubtotal()
                .multiply(porcentajeIva)
                .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
    }

    public BigDecimal calcularTotal() {
        return calcularSubtotal().add(calcularIva());
    }

    public UUID getProductoId() { return productoId; }
    public String getCodigoProducto() { return codigoProducto; }
    public String getDescripcionProducto() { return descripcionProducto; }
    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public int getCantidad() { return cantidad; }
    public BigDecimal getPorcentajeIva() { return porcentajeIva; }
}
