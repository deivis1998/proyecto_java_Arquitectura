package com.aca.facturacion.aplicacion;

import com.aca.facturacion.dominio.Cliente;
import com.aca.facturacion.dominio.ExcepcionNegocio;
import com.aca.facturacion.dominio.Factura;
import com.aca.facturacion.dominio.LineaFactura;
import com.aca.facturacion.dominio.Producto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

public class ServicioFacturacion {
    private final RepositorioClientes clientes;
    private final RepositorioProductos productos;
    private final RepositorioFacturas facturas;
    private final Supplier<LocalDateTime> ahora;

    public ServicioFacturacion(
            RepositorioClientes clientes,
            RepositorioProductos productos,
            RepositorioFacturas facturas) {
        this(clientes, productos, facturas, LocalDateTime::now);
    }

    public ServicioFacturacion(
            RepositorioClientes clientes,
            RepositorioProductos productos,
            RepositorioFacturas facturas,
            Supplier<LocalDateTime> ahora) {
        this.clientes = clientes;
        this.productos = productos;
        this.facturas = facturas;
        this.ahora = ahora;
    }

    public Factura crearFactura(CrearFacturaSolicitud solicitud) {
        Cliente cliente = clientes.buscarPorId(solicitud.clienteId())
                .orElseThrow(() -> new ExcepcionNegocio("El cliente seleccionado no existe."));
        cliente.validarPuedeFacturarse();

        if (solicitud.items().isEmpty()) {
            throw new ExcepcionNegocio("Debe agregar al menos un producto a la factura.");
        }

        Map<UUID, Integer> cantidades = new LinkedHashMap<>();
        for (ItemFacturaSolicitud item : solicitud.items()) {
            cantidades.merge(item.productoId(), item.cantidad(), Integer::sum);
        }

        List<ProductoCantidad> seleccionados = new ArrayList<>();
        for (Map.Entry<UUID, Integer> item : cantidades.entrySet()) {
            Producto producto = productos.buscarPorId(item.getKey())
                    .orElseThrow(() -> new ExcepcionNegocio("Uno de los productos no existe."));
            producto.validarStock(item.getValue());
            seleccionados.add(new ProductoCantidad(producto, item.getValue()));
        }

        List<LineaFactura> lineas = seleccionados.stream()
                .map(item -> new LineaFactura(item.producto(), item.cantidad()))
                .toList();

        String numero = "FAC-%06d".formatted(facturas.siguienteConsecutivo());
        Factura factura = new Factura(
                UUID.randomUUID(), numero, cliente, ahora.get(), lineas);

        // El inventario solo cambia después de validar toda la operación.
        for (ProductoCantidad item : seleccionados) {
            item.producto().descontarStock(item.cantidad());
            productos.actualizar(item.producto());
        }
        facturas.guardar(factura);
        return factura;
    }

    public void anularFactura(UUID facturaId) {
        Factura factura = buscarDetalle(facturaId);
        factura.anular(ahora.get());
        facturas.actualizar(factura);
    }

    public Factura buscarDetalle(UUID facturaId) {
        return facturas.buscarPorId(facturaId)
                .orElseThrow(() -> new ExcepcionNegocio("La factura no existe."));
    }

    public List<Factura> listar() {
        return facturas.listar();
    }

    public List<Factura> buscarPorCliente(UUID clienteId) {
        if (clientes.buscarPorId(clienteId).isEmpty()) {
            throw new ExcepcionNegocio("El cliente no existe.");
        }
        return facturas.buscarPorCliente(clienteId);
    }

    public List<Factura> buscarPorRango(LocalDate desde, LocalDate hasta) {
        if (desde.isAfter(hasta)) {
            throw new ExcepcionNegocio("La fecha inicial no puede ser posterior a la fecha final.");
        }
        return facturas.buscarPorRango(desde.atStartOfDay(), hasta.plusDays(1).atStartOfDay().minusNanos(1));
    }

    private record ProductoCantidad(Producto producto, int cantidad) {
    }
}
