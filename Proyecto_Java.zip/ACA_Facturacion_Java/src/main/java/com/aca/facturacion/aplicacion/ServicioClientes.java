package com.aca.facturacion.aplicacion;

import com.aca.facturacion.dominio.Cliente;
import com.aca.facturacion.dominio.EstadoCliente;
import com.aca.facturacion.dominio.ExcepcionNegocio;
import java.util.List;
import java.util.UUID;

public class ServicioClientes {
    private final RepositorioClientes repositorio;

    public ServicioClientes(RepositorioClientes repositorio) {
        this.repositorio = repositorio;
    }

    public Cliente registrar(
            String nombre,
            String identificacion,
            String correo,
            String direccion,
            String telefono,
            EstadoCliente estado) {
        if (repositorio.buscarPorIdentificacion(identificacion).isPresent()) {
            throw new ExcepcionNegocio("Ya existe un cliente con esa identificación/NIT.");
        }
        Cliente cliente = new Cliente(
                UUID.randomUUID(), nombre, identificacion, correo, direccion, telefono, estado);
        repositorio.guardar(cliente);
        return cliente;
    }

    public List<Cliente> listar() {
        return repositorio.listar();
    }

    public void cambiarEstado(UUID clienteId, EstadoCliente estado) {
        Cliente cliente = repositorio.buscarPorId(clienteId)
                .orElseThrow(() -> new ExcepcionNegocio("El cliente no existe."));
        cliente.cambiarEstado(estado);
        repositorio.actualizar(cliente);
    }
}
