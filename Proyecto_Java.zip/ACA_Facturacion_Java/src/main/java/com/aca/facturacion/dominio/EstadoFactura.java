package com.aca.facturacion.dominio;

public enum EstadoFactura {
    GENERADA,
    ANULADA
}
