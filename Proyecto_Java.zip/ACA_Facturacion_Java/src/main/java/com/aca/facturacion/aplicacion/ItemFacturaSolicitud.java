package com.aca.facturacion.aplicacion;

import java.util.UUID;

public record ItemFacturaSolicitud(UUID productoId, int cantidad) {
}
