package com.aca.facturacion.infraestructura;

import com.aca.facturacion.aplicacion.RepositorioFacturas;
import com.aca.facturacion.dominio.Factura;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class RepositorioFacturasMemoria implements RepositorioFacturas {
    private final Map<UUID, Factura> datos = new LinkedHashMap<>();
    private final AtomicInteger consecutivo = new AtomicInteger();

    @Override
    public Optional<Factura> buscarPorId(UUID id) {
        return Optional.ofNullable(datos.get(id));
    }

    @Override
    public Optional<Factura> buscarPorNumero(String numero) {
        return datos.values().stream()
                .filter(factura -> factura.getNumero().equalsIgnoreCase(numero.trim()))
                .findFirst();
    }

    @Override
    public List<Factura> listar() {
        return ordenar(datos.values().stream().toList());
    }

    @Override
    public List<Factura> buscarPorCliente(UUID clienteId) {
        return ordenar(datos.values().stream()
                .filter(factura -> factura.getClienteId().equals(clienteId))
                .toList());
    }

    @Override
    public List<Factura> buscarPorRango(LocalDateTime desde, LocalDateTime hasta) {
        return ordenar(datos.values().stream()
                .filter(factura -> !factura.getFecha().isBefore(desde) && !factura.getFecha().isAfter(hasta))
                .toList());
    }

    @Override
    public void guardar(Factura factura) {
        datos.put(factura.getId(), factura);
    }

    @Override
    public void actualizar(Factura factura) {
        datos.put(factura.getId(), factura);
    }

    @Override
    public int siguienteConsecutivo() {
        return consecutivo.incrementAndGet();
    }

    private List<Factura> ordenar(List<Factura> facturas) {
        List<Factura> resultado = new ArrayList<>(facturas);
        resultado.sort(Comparator.comparing(Factura::getFecha).reversed());
        return List.copyOf(resultado);
    }
}
