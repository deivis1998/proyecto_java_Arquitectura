package com.aca.facturacion.aplicacion;

import com.aca.facturacion.dominio.ExcepcionNegocio;
import com.aca.facturacion.dominio.Producto;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public class ServicioProductos {
    private final RepositorioProductos repositorio;

    public ServicioProductos(RepositorioProductos repositorio) {
        this.repositorio = repositorio;
    }

    public Producto registrar(
            String codigo,
            String descripcion,
            BigDecimal precio,
            int stock,
            BigDecimal iva) {
        if (repositorio.buscarPorCodigo(codigo).isPresent()) {
            throw new ExcepcionNegocio("Ya existe un producto con ese código.");
        }
        Producto producto = new Producto(
                UUID.randomUUID(), codigo, descripcion, precio, stock, iva);
        repositorio.guardar(producto);
        return producto;
    }

    public List<Producto> listar() {
        return repositorio.listar();
    }
}
