package com.aca.facturacion.dominio;

public enum EstadoCliente {
    ACTIVO,
    INACTIVO,
    BLOQUEADO_POR_MORA
}
