package com.aca.facturacion.aplicacion;

import com.aca.facturacion.dominio.Producto;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RepositorioProductos {
    Optional<Producto> buscarPorId(UUID id);
    Optional<Producto> buscarPorCodigo(String codigo);
    List<Producto> listar();
    void guardar(Producto producto);
    void actualizar(Producto producto);
}
