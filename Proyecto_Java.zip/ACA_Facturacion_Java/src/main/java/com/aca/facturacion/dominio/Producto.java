package com.aca.facturacion.dominio;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.UUID;

public class Producto {
    private final UUID id;
    private final String codigo;
    private final String descripcion;
    private final BigDecimal precioUnitario;
    private int stockDisponible;
    private final BigDecimal porcentajeIva;

    public Producto(
            UUID id,
            String codigo,
            String descripcion,
            BigDecimal precioUnitario,
            int stockDisponible,
            BigDecimal porcentajeIva) {
        this.id = Objects.requireNonNull(id, "El identificador es obligatorio");
        this.codigo = textoObligatorio(codigo, "El código es obligatorio");
        this.descripcion = textoObligatorio(descripcion, "La descripción es obligatoria");
        this.precioUnitario = noNegativo(precioUnitario, "El precio no puede ser negativo");
        if (stockDisponible < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo");
        }
        this.stockDisponible = stockDisponible;
        this.porcentajeIva = noNegativo(porcentajeIva, "El IVA no puede ser negativo");
        if (porcentajeIva.compareTo(new BigDecimal("100")) > 0) {
            throw new IllegalArgumentException("El IVA no puede superar el 100 %");
        }
    }

    public void validarStock(int cantidad) {
        if (cantidad <= 0) {
            throw new ExcepcionNegocio("La cantidad debe ser mayor que cero.");
        }
        if (cantidad > stockDisponible) {
            throw new ExcepcionNegocio(
                    "Stock insuficiente para " + descripcion
                            + ". Disponible: " + stockDisponible
                            + ", solicitado: " + cantidad + ".");
        }
    }

    public void descontarStock(int cantidad) {
        validarStock(cantidad);
        stockDisponible -= cantidad;
    }

    private static String textoObligatorio(String valor, String mensaje) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(mensaje);
        }
        return valor.trim();
    }

    private static BigDecimal noNegativo(BigDecimal valor, String mensaje) {
        Objects.requireNonNull(valor, mensaje);
        if (valor.signum() < 0) {
            throw new IllegalArgumentException(mensaje);
        }
        return valor;
    }

    public UUID getId() { return id; }
    public String getCodigo() { return codigo; }
    public String getDescripcion() { return descripcion; }
    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public int getStockDisponible() { return stockDisponible; }
    public BigDecimal getPorcentajeIva() { return porcentajeIva; }
}
