package com.aca.facturacion.dominio;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class Factura {
    private final UUID id;
    private final String numero;
    private final UUID clienteId;
    private final String nombreCliente;
    private final LocalDateTime fecha;
    private final List<LineaFactura> lineas;
    private EstadoFactura estado;
    private LocalDateTime fechaAnulacion;

    public Factura(
            UUID id,
            String numero,
            Cliente cliente,
            LocalDateTime fecha,
            List<LineaFactura> lineas) {
        this.id = Objects.requireNonNull(id, "El identificador es obligatorio");
        if (numero == null || numero.isBlank()) {
            throw new IllegalArgumentException("El número de factura es obligatorio");
        }
        Objects.requireNonNull(cliente, "El cliente es obligatorio");
        this.lineas = List.copyOf(Objects.requireNonNull(lineas, "Las líneas son obligatorias"));
        if (this.lineas.isEmpty()) {
            throw new ExcepcionNegocio("La factura debe contener al menos un producto.");
        }
        this.numero = numero.trim();
        this.clienteId = cliente.getId();
        this.nombreCliente = cliente.getNombreORazonSocial();
        this.fecha = Objects.requireNonNull(fecha, "La fecha es obligatoria");
        this.estado = EstadoFactura.GENERADA;
    }

    public BigDecimal calcularSubtotal() {
        return lineas.stream()
                .map(LineaFactura::calcularSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public BigDecimal calcularIva() {
        return lineas.stream()
                .map(LineaFactura::calcularIva)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public BigDecimal calcularTotal() {
        return calcularSubtotal().add(calcularIva());
    }

    public void anular(LocalDateTime momento) {
        if (estado == EstadoFactura.ANULADA) {
            throw new ExcepcionNegocio("Una factura anulada no puede volver a anularse.");
        }
        estado = EstadoFactura.ANULADA;
        fechaAnulacion = Objects.requireNonNull(momento, "La fecha de anulación es obligatoria");
    }

    public void validarModificable() {
        if (estado == EstadoFactura.ANULADA) {
            throw new ExcepcionNegocio("Una factura anulada no puede modificarse.");
        }
    }

    public UUID getId() { return id; }
    public String getNumero() { return numero; }
    public UUID getClienteId() { return clienteId; }
    public String getNombreCliente() { return nombreCliente; }
    public LocalDateTime getFecha() { return fecha; }
    public List<LineaFactura> getLineas() { return lineas; }
    public EstadoFactura getEstado() { return estado; }
    public LocalDateTime getFechaAnulacion() { return fechaAnulacion; }
}
