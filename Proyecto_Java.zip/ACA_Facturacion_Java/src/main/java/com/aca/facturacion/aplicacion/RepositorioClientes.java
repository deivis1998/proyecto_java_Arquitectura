package com.aca.facturacion.aplicacion;

import com.aca.facturacion.dominio.Cliente;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RepositorioClientes {
    Optional<Cliente> buscarPorId(UUID id);
    Optional<Cliente> buscarPorIdentificacion(String identificacion);
    List<Cliente> listar();
    void guardar(Cliente cliente);
    void actualizar(Cliente cliente);
}
