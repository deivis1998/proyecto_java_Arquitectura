package com.aca.facturacion.aplicacion;

import com.aca.facturacion.dominio.Cliente;
import com.aca.facturacion.dominio.EstadoCliente;
import com.aca.facturacion.dominio.ExcepcionNegocio;
import com.aca.facturacion.dominio.Factura;
import com.aca.facturacion.dominio.Producto;
import com.aca.facturacion.infraestructura.RepositorioClientesMemoria;
import com.aca.facturacion.infraestructura.RepositorioFacturasMemoria;
import com.aca.facturacion.infraestructura.RepositorioProductosMemoria;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ServicioFacturacionTest {

    @Test
    void calculaSubtotalIvaYTotal() {
        Contexto contexto = crearContexto(EstadoCliente.ACTIVO);
        Factura factura = crearFactura(contexto, 2);

        assertEquals(new BigDecimal("200000"), factura.calcularSubtotal());
        assertEquals(new BigDecimal("38000.00"), factura.calcularIva());
        assertEquals(new BigDecimal("238000.00"), factura.calcularTotal());
    }

    @Test
    void actualizaElInventario() {
        Contexto contexto = crearContexto(EstadoCliente.ACTIVO);
        crearFactura(contexto, 3);
        assertEquals(7, contexto.producto().getStockDisponible());
    }

    @Test
    void rechazaStockInsuficienteSinModificarInventario() {
        Contexto contexto = crearContexto(EstadoCliente.ACTIVO);
        ExcepcionNegocio error = assertThrows(ExcepcionNegocio.class,
                () -> crearFactura(contexto, 11));
        assertTrue(error.getMessage().contains("Stock insuficiente"));
        assertEquals(10, contexto.producto().getStockDisponible());
    }

    @Test
    void rechazaClienteInactivo() {
        Contexto contexto = crearContexto(EstadoCliente.INACTIVO);
        assertThrows(ExcepcionNegocio.class, () -> crearFactura(contexto, 1));
    }

    @Test
    void rechazaClienteBloqueadoPorMora() {
        Contexto contexto = crearContexto(EstadoCliente.BLOQUEADO_POR_MORA);
        assertThrows(ExcepcionNegocio.class, () -> crearFactura(contexto, 1));
    }

    @Test
    void impideAnularDosVeces() {
        Contexto contexto = crearContexto(EstadoCliente.ACTIVO);
        Factura factura = crearFactura(contexto, 1);
        contexto.servicio().anularFactura(factura.getId());
        assertThrows(ExcepcionNegocio.class,
                () -> contexto.servicio().anularFactura(factura.getId()));
    }

    @Test
    void impideModificarFacturaAnulada() {
        Contexto contexto = crearContexto(EstadoCliente.ACTIVO);
        Factura factura = crearFactura(contexto, 1);
        contexto.servicio().anularFactura(factura.getId());
        assertThrows(ExcepcionNegocio.class, factura::validarModificable);
    }

    @Test
    void consultaPorClienteYFecha() {
        LocalDateTime fecha = LocalDateTime.of(2026, 9, 10, 10, 0);
        Contexto contexto = crearContexto(EstadoCliente.ACTIVO, fecha);
        crearFactura(contexto, 1);

        assertEquals(1, contexto.servicio().buscarPorCliente(contexto.cliente().getId()).size());
        assertEquals(1, contexto.servicio().buscarPorRango(
                LocalDate.of(2026, 9, 10), LocalDate.of(2026, 9, 10)).size());
    }

    private Factura crearFactura(Contexto contexto, int cantidad) {
        return contexto.servicio().crearFactura(new CrearFacturaSolicitud(
                contexto.cliente().getId(),
                List.of(new ItemFacturaSolicitud(contexto.producto().getId(), cantidad))));
    }

    private Contexto crearContexto(EstadoCliente estado) {
        return crearContexto(estado, LocalDateTime.of(2026, 9, 10, 10, 0));
    }

    private Contexto crearContexto(EstadoCliente estado, LocalDateTime fecha) {
        RepositorioClientesMemoria clientes = new RepositorioClientesMemoria();
        RepositorioProductosMemoria productos = new RepositorioProductosMemoria();
        RepositorioFacturasMemoria facturas = new RepositorioFacturasMemoria();
        Cliente cliente = new Cliente(UUID.randomUUID(), "Cliente de prueba", "123",
                "cliente@prueba.com", "Bogotá", "3000000000", estado);
        Producto producto = new Producto(UUID.randomUUID(), "PR-01", "Producto de prueba",
                new BigDecimal("100000"), 10, new BigDecimal("19"));
        clientes.guardar(cliente);
        productos.guardar(producto);
        ServicioFacturacion servicio = new ServicioFacturacion(clientes, productos, facturas, () -> fecha);
        return new Contexto(servicio, cliente, producto);
    }

    private record Contexto(
            ServicioFacturacion servicio,
            Cliente cliente,
            Producto producto) {
    }
}
