# Instrucciones de trabajo para el equipo

## Objetivo

Los tres integrantes deben partir de este mismo proyecto. Cada persona trabajará en una copia individual y modificará únicamente los archivos que le corresponden. Después se reunirán las partes en una copia final.

El proyecto ya contiene una versión funcional de referencia. No es necesario cambiar nombres de paquetes, clases o métodos. Antes de entregar, cada integrante debe comprender y poder explicar sus archivos.

## Preparación

1. Una persona comparte `ACA_Facturacion_Java.zip` con el grupo.
2. Cada integrante descomprime el archivo en su computador.
3. Todos verifican que la carpeta contenga `pom.xml` y `src`.
4. No trabajen directamente dentro del archivo ZIP.
5. Cada persona conserva una copia original sin modificaciones.

## Integrante 1

### Código

Trabaja principalmente en:

```text
src/main/java/com/aca/facturacion/presentacion/Main.java
```

Debe revisar y comprender:

- Menú principal.
- Lectura y validación básica de datos.
- Registro y consulta de clientes.
- Registro y consulta de productos.
- Mensajes de éxito y error.

No debe trasladar reglas de stock, estado del cliente o cálculos al menú.

### Documento

- Portada.
- Introducción.
- Descripción del problema.
- Requerimientos funcionales y no funcionales.
- Casos de uso.
- Lista consolidada de reglas de negocio.

### Video

Explica el problema, las funcionalidades y las reglas entre 0:00 y 1:20.

## Integrante 2

### Código

Trabaja en:

```text
src/main/java/com/aca/facturacion/dominio/
```

Sus archivos son:

- `Cliente.java`.
- `Producto.java`.
- `Factura.java`.
- `LineaFactura.java`.
- `EstadoCliente.java`.
- `EstadoFactura.java`.
- `ExcepcionNegocio.java`.

Debe revisar y poder explicar:

- Validación del estado del cliente.
- Validación y descuento del stock.
- Uso de `BigDecimal` para dinero.
- Cálculo del subtotal, IVA y total.
- Anulación y protección de una factura anulada.

No debe agregar dependencias de la consola ni de los repositorios dentro del dominio.

### Documento

- Diagrama de arquitectura.
- Descripción de las cuatro capas.
- Justificación de la arquitectura.
- Bajo acoplamiento y alta cohesión.
- Consecuencias de cambiar el motor de base de datos.
- Diagrama de clases.

### Video

Explica la arquitectura, las capas y las entidades entre 1:20 y 2:45.

## Integrante 3

### Código

Trabaja en:

```text
src/main/java/com/aca/facturacion/aplicacion/
src/main/java/com/aca/facturacion/infraestructura/
src/test/java/com/aca/facturacion/aplicacion/
```

Debe revisar y comprender:

- Servicios de clientes y productos.
- Proceso completo de creación de facturas.
- Interfaces de repositorio.
- Repositorios en memoria.
- Consultas y anulación de facturas.
- Ocho pruebas con JUnit 5.

### Documento

- Pseudocódigo de `crearFactura`.
- Tabla de casos de prueba y resultados.
- Conclusiones.
- Referencias con normas APA.
- Integración de todas las secciones.
- Enlace del video en YouTube.

### Video

Demuestra el programa, las validaciones y las pruebas entre 2:45 y 4:40.

## Archivos que no deben cambiar sin consultar al grupo

- `pom.xml`.
- Nombres de paquetes.
- Nombres de clases.
- Enumerados de estados.
- Firmas de los repositorios.
- Firma del método `crearFactura`.

Si es necesario cambiar alguno, primero se informa a los otros dos integrantes.

## Cómo entregar cada parte al integrador

1. Copiar solamente las carpetas asignadas.
2. Comprimirlas en un ZIP con el nombre del integrante.
3. Adjuntar también el texto correspondiente del documento.
4. Indicar qué archivos fueron modificados.
5. No enviar toda la carpeta si contiene cambios ajenos.

Ejemplos:

```text
Integrante_1_presentacion.zip
Integrante_2_dominio.zip
Integrante_3_aplicacion_infraestructura_pruebas.zip
```

## Integración final

1. Crear una copia limpia del proyecto base.
2. Incorporar primero la carpeta `dominio`.
3. Incorporar `aplicacion` e `infraestructura`.
4. Incorporar `presentacion`.
5. Incorporar las pruebas.
6. Ejecutar `mvn test`.
7. Ejecutar `mvn clean compile exec:java`.
8. Probar una factura válida.
9. Probar un cliente inactivo o bloqueado.
10. Probar una cantidad superior al stock.
11. Unir el documento y revisar que los diagramas coincidan con el código.
12. Grabar el video y comprobar el enlace de YouTube.

## Reglas mínimas que deben funcionar

1. No facturar cantidades superiores al stock.
2. No facturar a clientes inactivos.
3. No facturar a clientes bloqueados por mora.
4. No modificar una factura anulada.
5. No anular dos veces la misma factura.
6. Calcular correctamente el subtotal.
7. Calcular el IVA de cada producto.
8. Calcular el total como subtotal más IVA.
9. Actualizar el inventario después de generar la factura.

## Recomendación

No entreguen el código sin comprenderlo. Cada integrante debe leer sus clases, ejecutar el programa y ensayar su explicación. El objetivo no es memorizar cada línea, sino entender qué responsabilidad tiene su capa y cómo se comunica con las demás.
